<?php $__env->startSection('content'); ?>
  <header style="margin-top: -72px" id="inicio" class="masthead bg-primary text-white text-center">
    <div class="container">
	<?php if(isset($mobile)): ?>
		<img class="img-fluid mb-3 d-block mx-auto" style="height: 200px" src='<?php echo e($mobile->url_photo); ?>' alt="">
		<h1 class="mb-0"><?php echo e($mobile->name); ?></h1>
      	<hr class="star-light">
      	<h2 class="font-weight-light mb-0">Valuation: <?php echo e($mobile->valuation); ?>/10</h2>
        <h2 class="font-weight-light mb-0">Number of Opinions: <?php echo e($mobile->range->name); ?></h2>
  <?php endif; ?>
   	    </div>
  </header>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* C:\xampp\htdocs\mobiles\resources\views/public/index.blade.php */ ?>